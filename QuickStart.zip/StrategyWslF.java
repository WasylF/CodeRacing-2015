import model.Car;
import model.Game;
import model.Move;
import model.World;

/**
 *
 * @author Wsl_F
 */
public class StrategyWslF {
        public void move(Car self, World world, Game game, Move move) {
        }
}
